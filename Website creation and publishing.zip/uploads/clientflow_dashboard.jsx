import { useState, useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

// --- Demo data (swap per client) ---
const CLIENT = {
  name: "A&E Solutions Group",
  industry: "HVAC & Mechanical",
  since: "June 2026",
};

const CALLS = [
  { id: 1, date: "Jun 27", time: "9:12 AM", caller: "Maria Lopez", duration: "2:34", type: "New Lead", outcome: "Appointment Booked", phone: "(713) 555-0142" },
  { id: 2, date: "Jun 27", time: "8:45 AM", caller: "James Park", duration: "1:48", type: "Existing Customer", outcome: "Info Provided", phone: "(281) 555-0198" },
  { id: 3, date: "Jun 26", time: "6:22 PM", caller: "Unknown", duration: "0:52", type: "Spam", outcome: "Filtered", phone: "(832) 555-0311" },
  { id: 4, date: "Jun 26", time: "4:15 PM", caller: "David Chen", duration: "3:11", type: "New Lead", outcome: "Appointment Booked", phone: "(713) 555-0267" },
  { id: 5, date: "Jun 26", time: "2:30 PM", caller: "Sarah Williams", duration: "1:22", type: "Existing Customer", outcome: "Transferred to Owner", phone: "(281) 555-0445" },
  { id: 6, date: "Jun 26", time: "11:05 AM", caller: "Robert Garcia", duration: "2:08", type: "New Lead", outcome: "Callback Scheduled", phone: "(832) 555-0189" },
  { id: 7, date: "Jun 25", time: "7:48 PM", caller: "Lisa Thompson", duration: "1:55", type: "New Lead", outcome: "Appointment Booked", phone: "(713) 555-0523" },
  { id: 8, date: "Jun 25", time: "3:33 PM", caller: "Mike Johnson", duration: "2:42", type: "Existing Customer", outcome: "Info Provided", phone: "(281) 555-0672" },
  { id: 9, date: "Jun 25", time: "10:18 AM", caller: "Amanda Brown", duration: "1:15", type: "New Lead", outcome: "Voicemail Left", phone: "(832) 555-0734" },
  { id: 10, date: "Jun 24", time: "5:50 PM", caller: "Carlos Rivera", duration: "3:28", type: "New Lead", outcome: "Appointment Booked", phone: "(713) 555-0891" },
  { id: 11, date: "Jun 24", time: "1:12 PM", caller: "Jennifer Lee", duration: "0:45", type: "Wrong Number", outcome: "Filtered", phone: "(281) 555-0156" },
  { id: 12, date: "Jun 24", time: "9:30 AM", caller: "Tom Bradley", duration: "2:18", type: "Existing Customer", outcome: "Transferred to Owner", phone: "(832) 555-0423" },
  { id: 13, date: "Jun 23", time: "8:02 PM", caller: "Nancy White", duration: "1:50", type: "New Lead", outcome: "Appointment Booked", phone: "(713) 555-0345" },
  { id: 14, date: "Jun 23", time: "12:44 PM", caller: "Kevin Martinez", duration: "2:55", type: "New Lead", outcome: "Callback Scheduled", phone: "(281) 555-0567" },
];

const WEEKLY = [
  { week: "May 26", calls: 18, booked: 4 },
  { week: "Jun 2", calls: 24, booked: 7 },
  { week: "Jun 9", calls: 31, booked: 9 },
  { week: "Jun 16", calls: 28, booked: 8 },
  { week: "Jun 23", calls: 35, booked: 12 },
];

const OUTCOME_COLORS = {
  "Appointment Booked": "#10b981",
  "Callback Scheduled": "#3b82f6",
  "Info Provided": "#8b5cf6",
  "Transferred to Owner": "#f59e0b",
  "Voicemail Left": "#6b7280",
  "Filtered": "#ef4444",
};

export default function Dashboard() {
  const [tab, setTab] = useState("overview");
  const [filter, setFilter] = useState("all");

  const stats = useMemo(() => {
    const total = CALLS.length;
    const booked = CALLS.filter(c => c.outcome === "Appointment Booked").length;
    const newLeads = CALLS.filter(c => c.type === "New Lead").length;
    const afterHours = CALLS.filter(c => {
      const h = parseInt(c.time.split(":")[0]);
      const ampm = c.time.includes("PM");
      const hour24 = ampm && h !== 12 ? h + 12 : (!ampm && h === 12 ? 0 : h);
      return hour24 < 8 || hour24 >= 18;
    }).length;
    const filtered = CALLS.filter(c => c.outcome === "Filtered").length;
    return { total, booked, newLeads, afterHours, filtered };
  }, []);

  const outcomeBreakdown = useMemo(() => {
    const map = {};
    CALLS.forEach(c => { map[c.outcome] = (map[c.outcome] || 0) + 1; });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, []);

  const filteredCalls = useMemo(() => {
    if (filter === "all") return CALLS;
    if (filter === "booked") return CALLS.filter(c => c.outcome === "Appointment Booked");
    if (filter === "leads") return CALLS.filter(c => c.type === "New Lead");
    if (filter === "afterhours") return CALLS.filter(c => {
      const h = parseInt(c.time.split(":")[0]);
      const ampm = c.time.includes("PM");
      const hour24 = ampm && h !== 12 ? h + 12 : (!ampm && h === 12 ? 0 : h);
      return hour24 < 8 || hour24 >= 18;
    });
    return CALLS;
  }, [filter]);

  return (
    <div style={{
      fontFamily: "'Inter', 'SF Pro Display', -apple-system, sans-serif",
      background: "#0f1117",
      color: "#e4e4e7",
      minHeight: "100vh",
      padding: 0,
      margin: 0,
    }}>
      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #0f1117 0%, #1a1d2e 100%)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        padding: "20px 24px",
      }}>
        <div style={{ maxWidth: 960, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{
                width: 38, height: 38, borderRadius: 10,
                background: "linear-gradient(135deg, #3b82f6, #06b6d4)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 18, fontWeight: 700, color: "#fff",
              }}>C</div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", color: "#3b82f6", textTransform: "uppercase" }}>ClientFlow AI</div>
                <div style={{ fontSize: 18, fontWeight: 700, color: "#f4f4f5", lineHeight: 1.2 }}>{CLIENT.name}</div>
              </div>
            </div>
            <div style={{
              fontSize: 12, color: "#71717a",
              background: "rgba(255,255,255,0.04)",
              padding: "6px 14px", borderRadius: 8,
              border: "1px solid rgba(255,255,255,0.06)",
            }}>
              Client since {CLIENT.since} · {CLIENT.industry}
            </div>
          </div>

          {/* Tabs */}
          <div style={{ display: "flex", gap: 4, marginTop: 20 }}>
            {[
              { id: "overview", label: "Overview" },
              { id: "calls", label: "Call Log" },
            ].map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                padding: "8px 18px", fontSize: 13, fontWeight: 600,
                borderRadius: 8, border: "none", cursor: "pointer",
                transition: "all 0.15s",
                background: tab === t.id ? "rgba(59,130,246,0.15)" : "transparent",
                color: tab === t.id ? "#60a5fa" : "#71717a",
              }}>{t.label}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 960, margin: "0 auto", padding: "24px 24px 40px" }}>

        {tab === "overview" && (
          <>
            {/* Stat Cards */}
            <div style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
              gap: 12, marginBottom: 28,
            }}>
              {[
                { label: "Total Calls", value: stats.total, color: "#3b82f6", sub: "This period" },
                { label: "Appointments Booked", value: stats.booked, color: "#10b981", sub: `${Math.round(stats.booked / stats.total * 100)}% conversion` },
                { label: "New Leads", value: stats.newLeads, color: "#8b5cf6", sub: "First-time callers" },
                { label: "After-Hours Saves", value: stats.afterHours, color: "#f59e0b", sub: "Calls you'd have missed" },
              ].map((s, i) => (
                <div key={i} style={{
                  background: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(255,255,255,0.06)",
                  borderRadius: 14, padding: "20px 18px",
                }}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: "#71717a", letterSpacing: "0.04em", textTransform: "uppercase" }}>{s.label}</div>
                  <div style={{ fontSize: 36, fontWeight: 800, color: s.color, lineHeight: 1.1, margin: "6px 0 4px" }}>{s.value}</div>
                  <div style={{ fontSize: 12, color: "#52525b" }}>{s.sub}</div>
                </div>
              ))}
            </div>

            {/* Chart + Breakdown */}
            <div style={{
              display: "grid",
              gridTemplateColumns: "1fr 280px",
              gap: 16,
            }}>
              {/* Weekly Chart */}
              <div style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: 14, padding: "20px 18px",
              }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: "#f4f4f5", marginBottom: 4 }}>Weekly Call Volume</div>
                <div style={{ fontSize: 12, color: "#52525b", marginBottom: 18 }}>Total calls vs. appointments booked</div>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={WEEKLY} barGap={3}>
                    <XAxis dataKey="week" tick={{ fill: "#52525b", fontSize: 11 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: "#52525b", fontSize: 11 }} axisLine={false} tickLine={false} width={28} />
                    <Tooltip
                      contentStyle={{
                        background: "#1a1d2e", border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: 10, fontSize: 12, color: "#e4e4e7",
                      }}
                      cursor={{ fill: "rgba(255,255,255,0.03)" }}
                    />
                    <Bar dataKey="calls" fill="#3b82f6" radius={[6, 6, 0, 0]} name="Total Calls" />
                    <Bar dataKey="booked" fill="#10b981" radius={[6, 6, 0, 0]} name="Booked" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Outcome Breakdown */}
              <div style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: 14, padding: "20px 18px",
              }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: "#f4f4f5", marginBottom: 16 }}>Call Outcomes</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {outcomeBreakdown.map(([outcome, count]) => {
                    const pct = Math.round(count / CALLS.length * 100);
                    const color = OUTCOME_COLORS[outcome] || "#6b7280";
                    return (
                      <div key={outcome}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                          <span style={{ fontSize: 12, fontWeight: 600, color: "#a1a1aa" }}>{outcome}</span>
                          <span style={{ fontSize: 12, fontWeight: 700, color }}>{count} <span style={{ color: "#52525b", fontWeight: 400 }}>({pct}%)</span></span>
                        </div>
                        <div style={{ height: 6, borderRadius: 3, background: "rgba(255,255,255,0.05)" }}>
                          <div style={{ height: 6, borderRadius: 3, background: color, width: `${pct}%`, transition: "width 0.5s" }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Value callout */}
            <div style={{
              marginTop: 20,
              background: "linear-gradient(135deg, rgba(16,185,129,0.08), rgba(59,130,246,0.08))",
              border: "1px solid rgba(16,185,129,0.15)",
              borderRadius: 14, padding: "20px 22px",
              display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12,
            }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: "#10b981" }}>Revenue Impact</div>
                <div style={{ fontSize: 13, color: "#a1a1aa", marginTop: 4 }}>
                  {stats.booked} appointments booked this period · {stats.afterHours} after-hours calls saved from going to voicemail
                </div>
              </div>
              <div style={{
                fontSize: 28, fontWeight: 800, color: "#10b981",
                background: "rgba(16,185,129,0.1)",
                padding: "8px 20px", borderRadius: 10,
              }}>
                ${stats.booked * 350}+
                <span style={{ fontSize: 11, fontWeight: 500, color: "#6b7280", display: "block", textAlign: "center" }}>est. value</span>
              </div>
            </div>
          </>
        )}

        {tab === "calls" && (
          <>
            {/* Filters */}
            <div style={{ display: "flex", gap: 6, marginBottom: 18, flexWrap: "wrap" }}>
              {[
                { id: "all", label: "All Calls" },
                { id: "booked", label: "Booked" },
                { id: "leads", label: "New Leads" },
                { id: "afterhours", label: "After Hours" },
              ].map(f => (
                <button key={f.id} onClick={() => setFilter(f.id)} style={{
                  padding: "6px 14px", fontSize: 12, fontWeight: 600,
                  borderRadius: 8, border: "1px solid",
                  cursor: "pointer", transition: "all 0.15s",
                  background: filter === f.id ? "rgba(59,130,246,0.12)" : "transparent",
                  color: filter === f.id ? "#60a5fa" : "#71717a",
                  borderColor: filter === f.id ? "rgba(59,130,246,0.3)" : "rgba(255,255,255,0.06)",
                }}>{f.label}</button>
              ))}
            </div>

            {/* Call Table */}
            <div style={{
              background: "rgba(255,255,255,0.03)",
              border: "1px solid rgba(255,255,255,0.06)",
              borderRadius: 14, overflow: "hidden",
            }}>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                  <thead>
                    <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                      {["Date", "Time", "Caller", "Phone", "Type", "Duration", "Outcome"].map(h => (
                        <th key={h} style={{
                          padding: "12px 14px", textAlign: "left",
                          fontSize: 11, fontWeight: 700, color: "#52525b",
                          letterSpacing: "0.05em", textTransform: "uppercase",
                          whiteSpace: "nowrap",
                        }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCalls.map((c, i) => (
                      <tr key={c.id} style={{
                        borderBottom: i < filteredCalls.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
                        transition: "background 0.1s",
                      }}
                        onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.02)"}
                        onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                      >
                        <td style={{ padding: "12px 14px", color: "#a1a1aa", whiteSpace: "nowrap" }}>{c.date}</td>
                        <td style={{ padding: "12px 14px", color: "#a1a1aa", whiteSpace: "nowrap" }}>{c.time}</td>
                        <td style={{ padding: "12px 14px", color: "#f4f4f5", fontWeight: 600 }}>{c.caller}</td>
                        <td style={{ padding: "12px 14px", color: "#71717a", fontFamily: "monospace", fontSize: 12 }}>{c.phone}</td>
                        <td style={{ padding: "12px 14px" }}>
                          <span style={{
                            fontSize: 11, fontWeight: 600,
                            padding: "3px 10px", borderRadius: 6,
                            background: c.type === "New Lead" ? "rgba(139,92,246,0.12)" :
                              c.type === "Existing Customer" ? "rgba(59,130,246,0.12)" :
                                "rgba(239,68,68,0.1)",
                            color: c.type === "New Lead" ? "#a78bfa" :
                              c.type === "Existing Customer" ? "#60a5fa" :
                                "#f87171",
                          }}>{c.type}</span>
                        </td>
                        <td style={{ padding: "12px 14px", color: "#a1a1aa", fontFamily: "monospace", fontSize: 12 }}>{c.duration}</td>
                        <td style={{ padding: "12px 14px" }}>
                          <span style={{
                            fontSize: 11, fontWeight: 600,
                            padding: "3px 10px", borderRadius: 6,
                            background: `${OUTCOME_COLORS[c.outcome]}18`,
                            color: OUTCOME_COLORS[c.outcome],
                          }}>{c.outcome}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div style={{ textAlign: "center", marginTop: 16, fontSize: 12, color: "#52525b" }}>
              Showing {filteredCalls.length} of {CALLS.length} calls
            </div>
          </>
        )}

        {/* Footer */}
        <div style={{
          marginTop: 40, paddingTop: 20,
          borderTop: "1px solid rgba(255,255,255,0.06)",
          display: "flex", justifyContent: "space-between", alignItems: "center",
          flexWrap: "wrap", gap: 8,
        }}>
          <div style={{ fontSize: 12, color: "#3f3f46" }}>
            Powered by <span style={{ color: "#3b82f6", fontWeight: 600 }}>ClientFlow AI</span> · AI Receptionist Service
          </div>
          <div style={{ fontSize: 11, color: "#3f3f46" }}>
            Last updated: Jun 27, 2026
          </div>
        </div>
      </div>
    </div>
  );
}
