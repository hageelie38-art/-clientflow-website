import { useState, useEffect, useMemo, useCallback } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const OUTCOME_COLORS = {
  "Appointment Booked": "#10b981",
  "Callback Scheduled": "#3b82f6",
  "Info Provided": "#8b5cf6",
  "Transferred to Owner": "#f59e0b",
  "Voicemail Left": "#6b7280",
  "Filtered": "#ef4444",
};

const OUTCOME_OPTIONS = Object.keys(OUTCOME_COLORS);
const TYPE_OPTIONS = ["New Lead", "Existing Customer", "Spam", "Wrong Number"];

const DEFAULT_CONFIG = {
  clientName: "A&E Solutions Group",
  industry: "HVAC & Mechanical",
  since: "June 2026",
  avgJobValue: 350,
};

const CSV_TEMPLATE = `date,time,caller,phone,type,duration,outcome
Jun 27,9:12 AM,Maria Lopez,(713) 555-0142,New Lead,2:34,Appointment Booked
Jun 27,8:45 AM,James Park,(281) 555-0198,Existing Customer,1:48,Info Provided`;

export default function Dashboard() {
  const [mode, setMode] = useState("client");
  const [pin, setPin] = useState("");
  const [pinInput, setPinInput] = useState("");
  const [tab, setTab] = useState("overview");
  const [filter, setFilter] = useState("all");
  const [calls, setCalls] = useState([]);
  const [config, setConfig] = useState(DEFAULT_CONFIG);
  const [csvText, setCsvText] = useState("");
  const [importMsg, setImportMsg] = useState(null);
  const [loading, setLoading] = useState(true);
  const [adminTab, setAdminTab] = useState("import");

  // Manual add form
  const [newCall, setNewCall] = useState({
    date: "", time: "", caller: "", phone: "", type: "New Lead", duration: "", outcome: "Appointment Booked",
  });

  // Load data from storage
  useEffect(() => {
    (async () => {
      try {
        const [callsRes, configRes, pinRes] = await Promise.all([
          window.storage.get("cf-calls").catch(() => null),
          window.storage.get("cf-config").catch(() => null),
          window.storage.get("cf-pin").catch(() => null),
        ]);
        if (callsRes?.value) setCalls(JSON.parse(callsRes.value));
        if (configRes?.value) setConfig(JSON.parse(configRes.value));
        if (pinRes?.value) setPin(pinRes.value);
      } catch (e) { console.error(e); }
      setLoading(false);
    })();
  }, []);

  // Save helpers
  const saveCalls = useCallback(async (newCalls) => {
    setCalls(newCalls);
    try { await window.storage.set("cf-calls", JSON.stringify(newCalls)); } catch (e) { console.error(e); }
  }, []);

  const saveConfig = useCallback(async (newConfig) => {
    setConfig(newConfig);
    try { await window.storage.set("cf-config", JSON.stringify(newConfig)); } catch (e) { console.error(e); }
  }, []);

  const savePin = useCallback(async (p) => {
    setPin(p);
    try { await window.storage.set("cf-pin", p); } catch (e) { console.error(e); }
  }, []);

  // CSV import
  const handleImport = useCallback(() => {
    try {
      const lines = csvText.trim().split("\n").filter(l => l.trim());
      if (lines.length < 2) { setImportMsg({ type: "error", text: "Need a header row + at least 1 data row" }); return; }

      const headers = lines[0].toLowerCase().split(",").map(h => h.trim());
      const reqd = ["date", "caller", "outcome"];
      const missing = reqd.filter(r => !headers.includes(r));
      if (missing.length) { setImportMsg({ type: "error", text: `Missing columns: ${missing.join(", ")}` }); return; }

      let imported = 0;
      let skipped = 0;
      const newCalls = [...calls];

      for (let i = 1; i < lines.length; i++) {
        const vals = lines[i].split(",").map(v => v.trim());
        if (vals.length < headers.length) { skipped++; continue; }

        const row = {};
        headers.forEach((h, j) => { row[h] = vals[j] || ""; });

        if (!row.date || !row.caller || !row.outcome) { skipped++; continue; }

        newCalls.push({
          id: Date.now() + i,
          date: row.date,
          time: row.time || "",
          caller: row.caller,
          phone: row.phone || "",
          type: row.type || "New Lead",
          duration: row.duration || "0:00",
          outcome: row.outcome,
        });
        imported++;
      }

      saveCalls(newCalls);
      setCsvText("");
      setImportMsg({
        type: "success",
        text: `${imported} calls imported${skipped ? `, ${skipped} rows skipped` : ""}. Total: ${newCalls.length} calls.`,
      });
    } catch (e) {
      setImportMsg({ type: "error", text: "Parse error — check your CSV format" });
    }
  }, [csvText, calls, saveCalls]);

  // Manual add
  const handleAddCall = useCallback(() => {
    if (!newCall.date || !newCall.caller) {
      setImportMsg({ type: "error", text: "Date and Caller name are required" }); return;
    }
    const updated = [{ ...newCall, id: Date.now() }, ...calls];
    saveCalls(updated);
    setNewCall({ date: "", time: "", caller: "", phone: "", type: "New Lead", duration: "", outcome: "Appointment Booked" });
    setImportMsg({ type: "success", text: "Call added" });
  }, [newCall, calls, saveCalls]);

  // Delete call
  const handleDelete = useCallback((id) => {
    saveCalls(calls.filter(c => c.id !== id));
  }, [calls, saveCalls]);

  // Clear all
  const handleClearAll = useCallback(() => {
    if (calls.length === 0) return;
    saveCalls([]);
    setImportMsg({ type: "success", text: "All calls cleared" });
  }, [calls, saveCalls]);

  // Stats
  const stats = useMemo(() => {
    const total = calls.length;
    if (!total) return { total: 0, booked: 0, newLeads: 0, afterHours: 0, filtered: 0 };
    const booked = calls.filter(c => c.outcome === "Appointment Booked").length;
    const newLeads = calls.filter(c => c.type === "New Lead").length;
    const afterHours = calls.filter(c => {
      if (!c.time) return false;
      const h = parseInt(c.time.split(":")[0]);
      const ampm = c.time.toUpperCase().includes("PM");
      const hour24 = ampm && h !== 12 ? h + 12 : (!ampm && h === 12 ? 0 : h);
      return hour24 < 8 || hour24 >= 18;
    }).length;
    const filtered = calls.filter(c => c.outcome === "Filtered").length;
    return { total, booked, newLeads, afterHours, filtered };
  }, [calls]);

  // Weekly chart data
  const weeklyData = useMemo(() => {
    const weeks = {};
    calls.forEach(c => {
      const key = c.date?.split(" ").slice(0, 2).join(" ") || "Unknown";
      if (!weeks[key]) weeks[key] = { week: key, calls: 0, booked: 0 };
      weeks[key].calls++;
      if (c.outcome === "Appointment Booked") weeks[key].booked++;
    });
    return Object.values(weeks).slice(-8);
  }, [calls]);

  const outcomeBreakdown = useMemo(() => {
    const map = {};
    calls.forEach(c => { map[c.outcome] = (map[c.outcome] || 0) + 1; });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [calls]);

  const filteredCalls = useMemo(() => {
    if (filter === "all") return calls;
    if (filter === "booked") return calls.filter(c => c.outcome === "Appointment Booked");
    if (filter === "leads") return calls.filter(c => c.type === "New Lead");
    if (filter === "afterhours") return calls.filter(c => {
      if (!c.time) return false;
      const h = parseInt(c.time.split(":")[0]);
      const ampm = c.time.toUpperCase().includes("PM");
      const hour24 = ampm && h !== 12 ? h + 12 : (!ampm && h === 12 ? 0 : h);
      return hour24 < 8 || hour24 >= 18;
    });
    return calls;
  }, [filter, calls]);

  // Styles
  const s = {
    bg: "#0f1117",
    card: "rgba(255,255,255,0.03)",
    border: "rgba(255,255,255,0.06)",
    text: "#e4e4e7",
    muted: "#71717a",
    dim: "#52525b",
    accent: "#3b82f6",
  };

  const inputStyle = {
    background: "rgba(255,255,255,0.05)",
    border: `1px solid ${s.border}`,
    borderRadius: 8, padding: "8px 12px",
    color: s.text, fontSize: 13,
    outline: "none", width: "100%",
    boxSizing: "border-box",
  };

  const btnPrimary = {
    padding: "10px 20px", fontSize: 13, fontWeight: 700,
    borderRadius: 8, border: "none", cursor: "pointer",
    background: s.accent, color: "#fff",
  };

  if (loading) {
    return (
      <div style={{ fontFamily: "Inter, sans-serif", background: s.bg, color: s.text, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ fontSize: 14, color: s.muted }}>Loading dashboard...</div>
      </div>
    );
  }

  // Admin pin gate
  if (mode === "admin_gate") {
    return (
      <div style={{ fontFamily: "Inter, sans-serif", background: s.bg, color: s.text, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 16, padding: 32, width: 320, textAlign: "center" }}>
          <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>Admin Access</div>
          <div style={{ fontSize: 13, color: s.muted, marginBottom: 20 }}>
            {pin ? "Enter your PIN" : "Set a new admin PIN"}
          </div>
          <input
            type="password" placeholder="4-digit PIN" maxLength={4}
            value={pinInput} onChange={e => setPinInput(e.target.value.replace(/\D/g, ""))}
            onKeyDown={e => {
              if (e.key === "Enter" && pinInput.length === 4) {
                if (!pin) { savePin(pinInput); setMode("admin"); setPinInput(""); }
                else if (pinInput === pin) { setMode("admin"); setPinInput(""); }
                else { setPinInput(""); setImportMsg({ type: "error", text: "Wrong PIN" }); }
              }
            }}
            style={{ ...inputStyle, textAlign: "center", fontSize: 24, letterSpacing: 12, marginBottom: 14 }}
          />
          {importMsg?.type === "error" && <div style={{ color: "#ef4444", fontSize: 12, marginBottom: 10 }}>{importMsg.text}</div>}
          <button onClick={() => {
            if (pinInput.length !== 4) return;
            if (!pin) { savePin(pinInput); setMode("admin"); setPinInput(""); setImportMsg(null); }
            else if (pinInput === pin) { setMode("admin"); setPinInput(""); setImportMsg(null); }
            else { setPinInput(""); setImportMsg({ type: "error", text: "Wrong PIN" }); }
          }} style={btnPrimary}>Enter</button>
          <div style={{ marginTop: 14 }}>
            <button onClick={() => { setMode("client"); setPinInput(""); setImportMsg(null); }} style={{ background: "none", border: "none", color: s.muted, fontSize: 12, cursor: "pointer" }}>← Back to dashboard</button>
          </div>
        </div>
      </div>
    );
  }

  // ===== ADMIN MODE =====
  if (mode === "admin") {
    return (
      <div style={{ fontFamily: "Inter, sans-serif", background: s.bg, color: s.text, minHeight: "100vh", padding: 0 }}>
        <div style={{ background: "linear-gradient(135deg, #0f1117, #1a1d2e)", borderBottom: `1px solid ${s.border}`, padding: "16px 24px" }}>
          <div style={{ maxWidth: 960, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg, #ef4444, #f97316)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 700, color: "#fff" }}>A</div>
              <div>
                <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.1em", color: "#ef4444", textTransform: "uppercase" }}>Admin Panel</div>
                <div style={{ fontSize: 15, fontWeight: 700 }}>{config.clientName}</div>
              </div>
            </div>
            <button onClick={() => setMode("client")} style={{ ...btnPrimary, background: "rgba(255,255,255,0.06)", fontSize: 12 }}>← Client View</button>
          </div>
        </div>

        <div style={{ maxWidth: 960, margin: "0 auto", padding: "20px 24px 40px" }}>
          {/* Admin tabs */}
          <div style={{ display: "flex", gap: 4, marginBottom: 20 }}>
            {[{ id: "import", label: "Import Calls" }, { id: "add", label: "Add Call" }, { id: "manage", label: "Manage Data" }, { id: "settings", label: "Client Settings" }].map(t => (
              <button key={t.id} onClick={() => { setAdminTab(t.id); setImportMsg(null); }} style={{
                padding: "7px 16px", fontSize: 12, fontWeight: 600, borderRadius: 8, border: "none", cursor: "pointer",
                background: adminTab === t.id ? "rgba(239,68,68,0.12)" : "transparent",
                color: adminTab === t.id ? "#f87171" : s.muted,
              }}>{t.label}</button>
            ))}
          </div>

          {importMsg && (
            <div style={{
              padding: "10px 16px", borderRadius: 10, marginBottom: 16, fontSize: 13, fontWeight: 600,
              background: importMsg.type === "success" ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)",
              color: importMsg.type === "success" ? "#10b981" : "#ef4444",
              border: `1px solid ${importMsg.type === "success" ? "rgba(16,185,129,0.2)" : "rgba(239,68,68,0.2)"}`,
            }}>{importMsg.text}</div>
          )}

          {/* CSV Import */}
          {adminTab === "import" && (
            <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, padding: 24 }}>
              <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 4 }}>Paste CSV Data</div>
              <div style={{ fontSize: 12, color: s.muted, marginBottom: 14 }}>
                Required columns: <span style={{ color: "#f4f4f5", fontWeight: 600 }}>date, caller, outcome</span>. Optional: time, phone, type, duration
              </div>
              <div style={{ marginBottom: 12 }}>
                <button onClick={() => setCsvText(CSV_TEMPLATE)} style={{ background: "none", border: "none", color: s.accent, fontSize: 12, cursor: "pointer", fontWeight: 600 }}>
                  Load example template ↓
                </button>
              </div>
              <textarea
                value={csvText} onChange={e => setCsvText(e.target.value)}
                placeholder="Paste your CSV here..."
                rows={10}
                style={{ ...inputStyle, fontFamily: "monospace", fontSize: 12, resize: "vertical" }}
              />
              <div style={{ display: "flex", gap: 10, marginTop: 14, alignItems: "center" }}>
                <button onClick={handleImport} style={btnPrimary}>Import Calls</button>
                <span style={{ fontSize: 12, color: s.dim }}>Current total: {calls.length} calls</span>
              </div>
            </div>
          )}

          {/* Manual Add */}
          {adminTab === "add" && (
            <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, padding: 24 }}>
              <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Add a Call Manually</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {[
                  { key: "date", label: "Date", placeholder: "Jun 27" },
                  { key: "time", label: "Time", placeholder: "9:12 AM" },
                  { key: "caller", label: "Caller Name", placeholder: "Maria Lopez" },
                  { key: "phone", label: "Phone", placeholder: "(713) 555-0142" },
                  { key: "duration", label: "Duration", placeholder: "2:34" },
                ].map(f => (
                  <div key={f.key}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: s.muted, marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.05em" }}>{f.label}</div>
                    <input value={newCall[f.key]} onChange={e => setNewCall(p => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder} style={inputStyle} />
                  </div>
                ))}
                <div>
                  <div style={{ fontSize: 11, fontWeight: 600, color: s.muted, marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.05em" }}>Type</div>
                  <select value={newCall.type} onChange={e => setNewCall(p => ({ ...p, type: e.target.value }))} style={inputStyle}>
                    {TYPE_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div style={{ gridColumn: "span 2" }}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: s.muted, marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.05em" }}>Outcome</div>
                  <select value={newCall.outcome} onChange={e => setNewCall(p => ({ ...p, outcome: e.target.value }))} style={inputStyle}>
                    {OUTCOME_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              </div>
              <button onClick={handleAddCall} style={{ ...btnPrimary, marginTop: 16 }}>Add Call</button>
            </div>
          )}

          {/* Manage / delete */}
          {adminTab === "manage" && (
            <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, padding: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <div style={{ fontSize: 15, fontWeight: 700 }}>{calls.length} Calls</div>
                <button onClick={handleClearAll} style={{ ...btnPrimary, background: "rgba(239,68,68,0.15)", color: "#f87171", fontSize: 12 }}>Clear All</button>
              </div>
              {calls.length === 0 ? (
                <div style={{ textAlign: "center", padding: 40, color: s.dim, fontSize: 13 }}>No calls yet. Import or add some above.</div>
              ) : (
                <div style={{ maxHeight: 400, overflowY: "auto" }}>
                  {calls.map(c => (
                    <div key={c.id} style={{
                      display: "flex", justifyContent: "space-between", alignItems: "center",
                      padding: "10px 0", borderBottom: `1px solid ${s.border}`,
                    }}>
                      <div>
                        <span style={{ fontWeight: 600, fontSize: 13 }}>{c.caller}</span>
                        <span style={{ color: s.muted, fontSize: 12, marginLeft: 10 }}>{c.date} {c.time}</span>
                        <span style={{ color: OUTCOME_COLORS[c.outcome] || s.muted, fontSize: 11, marginLeft: 10, fontWeight: 600 }}>{c.outcome}</span>
                      </div>
                      <button onClick={() => handleDelete(c.id)} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: 16, padding: "4px 8px" }}>×</button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Settings */}
          {adminTab === "settings" && (
            <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, padding: 24 }}>
              <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Client Settings</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {[
                  { key: "clientName", label: "Client Name" },
                  { key: "industry", label: "Industry" },
                  { key: "since", label: "Client Since" },
                  { key: "avgJobValue", label: "Avg Job Value ($)", type: "number" },
                ].map(f => (
                  <div key={f.key}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: s.muted, marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.05em" }}>{f.label}</div>
                    <input
                      type={f.type || "text"}
                      value={config[f.key]}
                      onChange={e => {
                        const val = f.type === "number" ? Number(e.target.value) : e.target.value;
                        setConfig(p => ({ ...p, [f.key]: val }));
                      }}
                      style={inputStyle}
                    />
                  </div>
                ))}
              </div>
              <button onClick={() => { saveConfig(config); setImportMsg({ type: "success", text: "Settings saved" }); }} style={{ ...btnPrimary, marginTop: 16 }}>Save Settings</button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ===== CLIENT VIEW =====
  return (
    <div style={{ fontFamily: "'Inter', -apple-system, sans-serif", background: s.bg, color: s.text, minHeight: "100vh" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #0f1117, #1a1d2e)", borderBottom: `1px solid ${s.border}`, padding: "20px 24px" }}>
        <div style={{ maxWidth: 960, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: "linear-gradient(135deg, #3b82f6, #06b6d4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 700, color: "#fff" }}>C</div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", color: s.accent, textTransform: "uppercase" }}>ClientFlow AI</div>
                <div style={{ fontSize: 18, fontWeight: 700, color: "#f4f4f5" }}>{config.clientName}</div>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ fontSize: 12, color: s.muted, background: "rgba(255,255,255,0.04)", padding: "6px 14px", borderRadius: 8, border: `1px solid ${s.border}` }}>
                Client since {config.since} · {config.industry}
              </div>
              <button onClick={() => setMode("admin_gate")} style={{ background: "none", border: "none", color: "#27272a", cursor: "pointer", fontSize: 10 }}>●</button>
            </div>
          </div>
          <div style={{ display: "flex", gap: 4, marginTop: 20 }}>
            {[{ id: "overview", label: "Overview" }, { id: "calls", label: "Call Log" }].map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                padding: "8px 18px", fontSize: 13, fontWeight: 600, borderRadius: 8, border: "none", cursor: "pointer",
                background: tab === t.id ? "rgba(59,130,246,0.15)" : "transparent",
                color: tab === t.id ? "#60a5fa" : s.muted,
              }}>{t.label}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 960, margin: "0 auto", padding: "24px 24px 40px" }}>
        {calls.length === 0 ? (
          <div style={{ textAlign: "center", padding: "80px 20px" }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>📞</div>
            <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>No call data yet</div>
            <div style={{ fontSize: 13, color: s.muted }}>Your AI receptionist activity will appear here once calls start coming in.</div>
          </div>
        ) : tab === "overview" ? (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(155px, 1fr))", gap: 12, marginBottom: 28 }}>
              {[
                { label: "Total Calls", value: stats.total, color: "#3b82f6", sub: "This period" },
                { label: "Appointments Booked", value: stats.booked, color: "#10b981", sub: stats.total ? `${Math.round(stats.booked / stats.total * 100)}% conversion` : "—" },
                { label: "New Leads", value: stats.newLeads, color: "#8b5cf6", sub: "First-time callers" },
                { label: "After-Hours Saves", value: stats.afterHours, color: "#f59e0b", sub: "Calls you'd have missed" },
              ].map((st, i) => (
                <div key={i} style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, padding: "20px 18px" }}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: s.muted, letterSpacing: "0.04em", textTransform: "uppercase" }}>{st.label}</div>
                  <div style={{ fontSize: 36, fontWeight: 800, color: st.color, lineHeight: 1.1, margin: "6px 0 4px" }}>{st.value}</div>
                  <div style={{ fontSize: 12, color: s.dim }}>{st.sub}</div>
                </div>
              ))}
            </div>

            {weeklyData.length > 1 && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 280px", gap: 16 }}>
                <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, padding: "20px 18px" }}>
                  <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 4 }}>Call Volume</div>
                  <div style={{ fontSize: 12, color: s.dim, marginBottom: 18 }}>Total calls vs. appointments booked</div>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={weeklyData} barGap={3}>
                      <XAxis dataKey="week" tick={{ fill: s.dim, fontSize: 11 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: s.dim, fontSize: 11 }} axisLine={false} tickLine={false} width={28} />
                      <Tooltip contentStyle={{ background: "#1a1d2e", border: `1px solid rgba(255,255,255,0.1)`, borderRadius: 10, fontSize: 12, color: s.text }} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
                      <Bar dataKey="calls" fill="#3b82f6" radius={[6, 6, 0, 0]} name="Total Calls" />
                      <Bar dataKey="booked" fill="#10b981" radius={[6, 6, 0, 0]} name="Booked" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, padding: "20px 18px" }}>
                  <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 16 }}>Call Outcomes</div>
                  {outcomeBreakdown.map(([outcome, count]) => {
                    const pct = Math.round(count / calls.length * 100);
                    const color = OUTCOME_COLORS[outcome] || s.muted;
                    return (
                      <div key={outcome} style={{ marginBottom: 10 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                          <span style={{ fontSize: 12, fontWeight: 600, color: "#a1a1aa" }}>{outcome}</span>
                          <span style={{ fontSize: 12, fontWeight: 700, color }}>{count} <span style={{ color: s.dim, fontWeight: 400 }}>({pct}%)</span></span>
                        </div>
                        <div style={{ height: 6, borderRadius: 3, background: "rgba(255,255,255,0.05)" }}>
                          <div style={{ height: 6, borderRadius: 3, background: color, width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {stats.booked > 0 && (
              <div style={{ marginTop: 20, background: "linear-gradient(135deg, rgba(16,185,129,0.08), rgba(59,130,246,0.08))", border: "1px solid rgba(16,185,129,0.15)", borderRadius: 14, padding: "20px 22px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "#10b981" }}>Revenue Impact</div>
                  <div style={{ fontSize: 13, color: "#a1a1aa", marginTop: 4 }}>
                    {stats.booked} appointments booked · {stats.afterHours} after-hours calls saved
                  </div>
                </div>
                <div style={{ fontSize: 28, fontWeight: 800, color: "#10b981", background: "rgba(16,185,129,0.1)", padding: "8px 20px", borderRadius: 10 }}>
                  ${(stats.booked * config.avgJobValue).toLocaleString()}+
                  <span style={{ fontSize: 11, fontWeight: 500, color: s.muted, display: "block", textAlign: "center" }}>est. value</span>
                </div>
              </div>
            )}
          </>
        ) : (
          <>
            <div style={{ display: "flex", gap: 6, marginBottom: 18, flexWrap: "wrap" }}>
              {[{ id: "all", label: "All Calls" }, { id: "booked", label: "Booked" }, { id: "leads", label: "New Leads" }, { id: "afterhours", label: "After Hours" }].map(f => (
                <button key={f.id} onClick={() => setFilter(f.id)} style={{
                  padding: "6px 14px", fontSize: 12, fontWeight: 600, borderRadius: 8, cursor: "pointer",
                  background: filter === f.id ? "rgba(59,130,246,0.12)" : "transparent",
                  color: filter === f.id ? "#60a5fa" : s.muted,
                  border: `1px solid ${filter === f.id ? "rgba(59,130,246,0.3)" : s.border}`,
                }}>{f.label}</button>
              ))}
            </div>
            <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, overflow: "hidden" }}>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                  <thead>
                    <tr style={{ borderBottom: `1px solid ${s.border}` }}>
                      {["Date", "Time", "Caller", "Phone", "Type", "Duration", "Outcome"].map(h => (
                        <th key={h} style={{ padding: "12px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: s.dim, letterSpacing: "0.05em", textTransform: "uppercase", whiteSpace: "nowrap" }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCalls.map((c, i) => (
                      <tr key={c.id} style={{ borderBottom: i < filteredCalls.length - 1 ? `1px solid rgba(255,255,255,0.04)` : "none" }}>
                        <td style={{ padding: "12px 14px", color: "#a1a1aa", whiteSpace: "nowrap" }}>{c.date}</td>
                        <td style={{ padding: "12px 14px", color: "#a1a1aa", whiteSpace: "nowrap" }}>{c.time}</td>
                        <td style={{ padding: "12px 14px", color: "#f4f4f5", fontWeight: 600 }}>{c.caller}</td>
                        <td style={{ padding: "12px 14px", color: s.muted, fontFamily: "monospace", fontSize: 12 }}>{c.phone}</td>
                        <td style={{ padding: "12px 14px" }}>
                          <span style={{
                            fontSize: 11, fontWeight: 600, padding: "3px 10px", borderRadius: 6,
                            background: c.type === "New Lead" ? "rgba(139,92,246,0.12)" : c.type === "Existing Customer" ? "rgba(59,130,246,0.12)" : "rgba(239,68,68,0.1)",
                            color: c.type === "New Lead" ? "#a78bfa" : c.type === "Existing Customer" ? "#60a5fa" : "#f87171",
                          }}>{c.type}</span>
                        </td>
                        <td style={{ padding: "12px 14px", color: "#a1a1aa", fontFamily: "monospace", fontSize: 12 }}>{c.duration}</td>
                        <td style={{ padding: "12px 14px" }}>
                          <span style={{ fontSize: 11, fontWeight: 600, padding: "3px 10px", borderRadius: 6, background: `${OUTCOME_COLORS[c.outcome] || s.muted}18`, color: OUTCOME_COLORS[c.outcome] || s.muted }}>{c.outcome}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div style={{ textAlign: "center", marginTop: 16, fontSize: 12, color: s.dim }}>Showing {filteredCalls.length} of {calls.length} calls</div>
          </>
        )}

        <div style={{ marginTop: 40, paddingTop: 20, borderTop: `1px solid ${s.border}`, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
          <div style={{ fontSize: 12, color: "#3f3f46" }}>Powered by <span style={{ color: s.accent, fontWeight: 600 }}>ClientFlow AI</span> · AI Receptionist Service</div>
          <div style={{ fontSize: 11, color: "#3f3f46" }}>Last updated: {new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</div>
        </div>
      </div>
    </div>
  );
}
